###Tested by TerminatorJ
###To run the GNL-Scorer, you should follow the instruction in https://github.com/TerminatorJ/CRISPR-TRAP-seq
###The script below should be run inthe same direction of "prediction.py"
import featurization
import prediction
import pandas as pd
import numpy as np
def val_pam(array_):
    array=np.array([i for i in array_ if i[25:27]=="GG"],dtype="unicode")
    new_array=np.array([j[0:30] for j in array],dtype="unicode")
    return new_array

  

def get_to_file(typ):
    df=pd.read_excel("dataset_validation.xlsx",sheet_name=typ)
    df_seq=df["30mer"].values
    df_eff=df["Efficiency"].values
    df_seq1=val_pam(df_seq)
    new_str=""
    all_list=[]
    for index,i in enumerate(df_seq1):
        num=index+1
        print(num)
        ele=">"+str(num)+"\n"+str(i)+"\n"
        new_str+=ele
        if num%9==0:##because the quikfold can just run the pipline maximum 9 jobs!!!
            with open("%d.fasta" % num,"w") as f1:
                f1.write(new_str)
            new_str=""
            input_matrix=featurization.get_input("%d.fasta" % num)
            output=prediction.predict(input_matrix,typ="Cas9",full_length=True)
            all_list+=list(output)
        elif num==len(df_seq1) or (len(df_seq1)-num)==(len(df_seq1)%9-1):
            new_str=""
            print("number left:%s" % str(int(len(df_seq1))-num))
            for i in df_seq1[index:]:  
                ele=">"+str(num)+"\n"+i+"\n"
                num+=1
                new_str+=ele
            with open("%d.fasta" % num,"w") as f2:
                f2.write(new_str)
            input_matrix=featurization.get_input("%d.fasta" % num)
            output=prediction.predict(input_matrix,typ="Cas9",full_length=True)
            all_list+=list(output)
            break
    rsl=pd.DataFrame({"30mer":df_seq1,"GNL-Scorer":all_list})
    rsl.to_csv("%s_GNL_result.csv" % typ,sep=",")


get_to_file("HEL")
get_to_file("Doench_V1")
get_to_file("Doench_V2")
get_to_file("HL60")
get_to_file("hela_2")
get_to_file("hela_1")
get_to_file("hek293t")
get_to_file("hct116_1")
get_to_file("Trap-seq")