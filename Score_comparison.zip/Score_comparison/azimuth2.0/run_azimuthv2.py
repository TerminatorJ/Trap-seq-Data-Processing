import pandas as pd
import numpy as np
import azimuth.model_comparison
import scipy.stats as st
def val_pam(array_):
    array=np.array([i for i in array_ if i[25:27]=="GG"],dtype="unicode")
    new_array=np.array([j[0:30] for j in array],dtype="unicode")
    return new_array
def get_to_file(typ):
    df=pd.read_excel("dataset_validation.xlsx",sheet_name=typ)
    df_seq=df["30mer"].values
    df_eff=df["Efficiency"].values
    df_seq=val_pam(df_seq)
    predictions = azimuth.model_comparison.predict(df_seq, None,None)
    #r=st.spearmanr(predictions,df_eff)[0]
    rsl=pd.DataFrame({"30mer":df_seq,"azimuth2.0":predictions})
    rsl.to_csv("%s_azimuth2.0_result.csv" % typ,sep=",")
get_to_file("Trap-seq")
get_to_file("HEL")
get_to_file("Doench_V1")
get_to_file("Doench_V2")
get_to_file("HL60")
get_to_file("hela_2")
get_to_file("hela_1")
get_to_file("hek293t")
get_to_file("hct116_1")