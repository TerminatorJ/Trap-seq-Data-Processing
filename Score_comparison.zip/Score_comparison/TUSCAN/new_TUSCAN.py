#!/usr/bin/env python

#Given a sequence, this program uses a Random Forest to predict the activity
#via a feature matrix, using a predefined master model created using a training set

# USAGE:
# Users can use the TUSCAN model in 3 ways:
# 1. Only supply a fasta file. The entire sequence will be analysed. Output will show: Chrom: N/A. Candidate site locations will be 0-based.
# 2. Supply a fasta file with known chrom/position information. The entire sequence will be analysed. Output will show supplied chromosome info, and position relative to supplied start/finish positions. 
# 3. Supply a fasta file, include chrom/position information for a region to extract. Include the -e flag with no arguments. The region of interest (start pos -> end pos) will be extracted and analysed. Output will reflect start position relative to supplied start/end position and chrom info.

# Users can also supply a thread number for multithreading using -t. If none supplied, default thread depending on available cores will be set. (-t [THREADS (int)])
# Users can also supply an output file name (recommended), otherwise output is written to TUSCAN_output.txt and overwritten upon each iteration (-o [FILENAME])
# Users must also specify whether regression or classification is required (-m [Regression/Classification])

# NOTE: Final output will be in arbitrary order due to multithreading. 
# Output is tab-separated and easy for users to manipulate using UNIX sort or other flavours. 
# Ouput is in bed6 format, with the unique ID being chrom_start_stop_targetSequence

import sys
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.externals import joblib
import numpy
#import pybedtools
import argparse
from collections import OrderedDict, namedtuple
import os
import re
import pandas as pd
import numpy as np
# from string import maketrans
from multiprocessing import Process, Queue, cpu_count

NucleotideLocation = namedtuple('NucleotideLocation', ['nucleotide', 'location'])

DinucleotideLocation = namedtuple('DinucleotideLocation', ['dinucleotide', 'location'])

REGRESSION_NUCLEOTIDES_OF_INTEREST = (
    NucleotideLocation(nucleotide='T', location=4),
    NucleotideLocation(nucleotide='C', location=7),
    NucleotideLocation(nucleotide='C', location=10),
    NucleotideLocation(nucleotide='T', location=17),
    NucleotideLocation(nucleotide='C', location=20),
    NucleotideLocation(nucleotide='T', location=20),
    NucleotideLocation(nucleotide='G', location=21),
    NucleotideLocation(nucleotide='T', location=21),
    NucleotideLocation(nucleotide='G', location=22),
    NucleotideLocation(nucleotide='T', location=22),
    NucleotideLocation(nucleotide='C', location=24),
    NucleotideLocation(nucleotide='G', location=24),
    NucleotideLocation(nucleotide='T', location=24)
)

CLASSIFICATION_NUCLEOTIDES_OF_INTEREST = (
    NucleotideLocation(nucleotide='G', location=5),
    NucleotideLocation(nucleotide='T', location=11),
    NucleotideLocation(nucleotide='C', location=12),
    NucleotideLocation(nucleotide='A', location=16),
    NucleotideLocation(nucleotide='T', location=17),
    NucleotideLocation(nucleotide='C', location=20),
    NucleotideLocation(nucleotide='T', location=20),
    NucleotideLocation(nucleotide='T', location=22),
    NucleotideLocation(nucleotide='T', location=23),
    NucleotideLocation(nucleotide='C', location=24),
    NucleotideLocation(nucleotide='G', location=24),
    NucleotideLocation(nucleotide='T', location=24),
)

REGRESSION_DINUCLEOTIDES_OF_INTEREST = (
    DinucleotideLocation(dinucleotide='AC', location=1),
    DinucleotideLocation(dinucleotide='AC', location=2),
    DinucleotideLocation(dinucleotide='CA', location=3),
    DinucleotideLocation(dinucleotide='TT', location=4),
    DinucleotideLocation(dinucleotide='GA', location=5),
    DinucleotideLocation(dinucleotide='CT', location=6),
    DinucleotideLocation(dinucleotide='AC', location=8),
    DinucleotideLocation(dinucleotide='CC', location=8),
    DinucleotideLocation(dinucleotide='GA', location=8),
    DinucleotideLocation(dinucleotide='TT', location=9),
    DinucleotideLocation(dinucleotide='AT', location=10),
    DinucleotideLocation(dinucleotide='CG', location=11),
    DinucleotideLocation(dinucleotide='GA', location=12),
    DinucleotideLocation(dinucleotide='CC', location=14),
    DinucleotideLocation(dinucleotide='GA', location=15),
    DinucleotideLocation(dinucleotide='CC', location=16),
    DinucleotideLocation(dinucleotide='GG', location=16),
    DinucleotideLocation(dinucleotide='TT', location=16),
    DinucleotideLocation(dinucleotide='CT', location=17),
    DinucleotideLocation(dinucleotide='AA', location=18),
    DinucleotideLocation(dinucleotide='GG', location=19),
    DinucleotideLocation(dinucleotide='AT', location=20),
    DinucleotideLocation(dinucleotide='CC', location=20),
    DinucleotideLocation(dinucleotide='CG', location=20),
    DinucleotideLocation(dinucleotide='CT', location=20),
    DinucleotideLocation(dinucleotide='GG', location=20),
    DinucleotideLocation(dinucleotide='TA', location=21),
    DinucleotideLocation(dinucleotide='TG', location=21),
    DinucleotideLocation(dinucleotide='CC', location=22),
    DinucleotideLocation(dinucleotide='GA', location=22),
    DinucleotideLocation(dinucleotide='TA', location=22),
    DinucleotideLocation(dinucleotide='CG', location=23),
    DinucleotideLocation(dinucleotide='GA', location=23),
    DinucleotideLocation(dinucleotide='GG', location=23),
    DinucleotideLocation(dinucleotide='TG', location=23),
    DinucleotideLocation(dinucleotide='GA', location=24),
    DinucleotideLocation(dinucleotide='GT', location=24),
    DinucleotideLocation(dinucleotide='TC', location=24),
)

CLASSIFICATION_DINUCLEOTIDES_OF_INTEREST = (
    DinucleotideLocation(dinucleotide='CG', location=11),
    DinucleotideLocation(dinucleotide='GA', location=15),
    DinucleotideLocation(dinucleotide='TT', location=16),
    DinucleotideLocation(dinucleotide='CC', location=20),
    DinucleotideLocation(dinucleotide='TA', location=22),
    DinucleotideLocation(dinucleotide='CG', location=23),
    DinucleotideLocation(dinucleotide='TC', location=23),
    DinucleotideLocation(dinucleotide='TG', location=23),
    DinucleotideLocation(dinucleotide='CC', location=24),
    DinucleotideLocation(dinucleotide='GA', location=24),
    DinucleotideLocation(dinucleotide='GC', location=24),
    DinucleotideLocation(dinucleotide='GT', location=24),
    DinucleotideLocation(dinucleotide='TC', location=24),
)

CLASSIFICATION_DINUCLEOTIDES = [
    'AA',
    'AC',
    'AG',
    'AT',
    'CA',
    'CC',
    'CG',
    'CT',
    'GA',
    'GC',
    'GG',
    'GT',
    'TA',
    'TC',
    'TG',
    'TT',
]

REGRESSION_DINUCLEOTIDES = [
    'CA',
    'CT',
    'GC',
    'TC',
    'TG',
    'TT',
]

#determines gc content of given sequence
def gc(seq, features, index):
    features[index] = round((seq.count('C') + seq.count('G'))/float(len(seq)) * 100, 2)

#counts appearance of dinucleotides in sequence
def di_content(seq, dinucleotides_to_count, features, start_index):
    for idx, dinucleotide in enumerate(dinucleotides_to_count):
        count = start = 0
        while True:
            start = seq.find(dinucleotide, start) + 1
            if start:
                count += 1
            else:
                features[start_index+idx] = count
                break

#checks if specific PAM is present in sequence
def pam(seq, features, index):
    if seq[24:28] == 'TGGT':
        features[index] = 1

#checks if given position-specific nucleotides are present in sequence
def nucleotide(seq, nucleotides_of_interest, features, start_index):
    for idx, nucleotide_loc in enumerate(nucleotides_of_interest):
        if seq[nucleotide_loc.location-1] == nucleotide_loc.nucleotide:
            features[start_index+idx] = 1

#checks if given position-specific dinucleotides are present in sequence
def dinucleotide(seq, dinucleotides_of_interest, features, start_index):
    #-1 is since a sequence of length N has N-1 dinucleotides
    for idx, dinucleotides_loc in enumerate(dinucleotides_of_interest):
        location = dinucleotides_loc.location
        if seq[location-1:location+1] == dinucleotides_loc.dinucleotide:
            features[start_index+idx] = 1

#generates a feature vector from a given 30 nucleotide sequence
def get_features(seq, is_regression):
    if is_regression:
        features = [0] * 63
        gc(seq, features, 0)
        features[1] = seq.count('A')
        features[2] = seq.count('C')
        features[3] = seq.count('G')
        features[4] = seq.count('T')
        di_content(seq, REGRESSION_DINUCLEOTIDES, features, 5)
        nucleotide(seq, REGRESSION_NUCLEOTIDES_OF_INTEREST, features, 11)
        dinucleotide(seq, REGRESSION_DINUCLEOTIDES_OF_INTEREST, features, 24)
        pam(seq, features, 62)
    else:
        features = [0] * 46
        gc(seq, features, 0)
        features[1] = seq.count('A')
        features[2] = seq.count('C')
        features[3] = seq.count('G')
        features[4] = seq.count('T')
        di_content(seq, CLASSIFICATION_DINUCLEOTIDES, features, 5)
        nucleotide(seq, CLASSIFICATION_NUCLEOTIDES_OF_INTEREST, features, 21)
        dinucleotide(seq, CLASSIFICATION_DINUCLEOTIDES_OF_INTEREST, features, 33)
    return features
def val_pam(array_):
    array=np.array([i for i in array_ if i[25:27]=="GG"],dtype="unicode")
    new_array=np.array([j[0:30] for j in array],dtype="unicode")
    return new_array
def get_to_file(typ):
    df=pd.read_excel("../../../dataset_validation.xlsx",sheet_name=typ)
    dir = os.path.dirname(os.path.realpath(__file__))
    rfm = dir + '/rfModelregressor.joblib'
    with open(rfm, 'rb') as f:
        rf = joblib.load(f)
    df_seq=df["30mer"].values
    score_lst=[]
    j=0
    df_seq=val_pam(df_seq)
    for i in df_seq:
        j+=1
        print("%s is going on" % j)
        feature_list = get_features(i, is_regression=True)
        feature_array = numpy.array(feature_list).reshape(1,-1)
        scores = rf.predict(feature_array)
        score_lst.append(scores[0])
    
    
    #r=st.spearmanr(predictions,df_eff)[0]
    print(df_seq.shape)
    print(len(score_lst))
    rsl=pd.DataFrame({"30mer":list(df_seq),"TUSCAN score":score_lst})
    rsl.to_csv("%s_TUSCAN_result.csv" % typ,sep=",")
	
if __name__=="__main__":
    #get_to_file("Trap-seq")
    #get_to_file("HEL")
    get_to_file("Doench_V1")
    get_to_file("Doench_V2")
    get_to_file("HL60")
    get_to_file("hela_2")
    get_to_file("hela_1")
    get_to_file("hek293t")
    get_to_file("hct116_1")
    