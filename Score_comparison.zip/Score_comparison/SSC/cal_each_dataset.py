#!/bin/python
import pandas as pd
import numpy as np
import os
#######Trap-seq data
def val_pam(array_):
    array=np.array([i for i in array_ if i[25:27]=="GG"],dtype="unicode")
    new_array=np.array([j[0:30] for j in array],dtype="unicode")
    return new_array

def get_std_fasta(raw_fasta):
    seq=raw_fasta.split("\n")[1]
    header=raw_fasta.split("\n")[0]
    num_i=int((((len(seq))-(len(seq)%50))/50)+1)
    inter=0
    k=1
    for j in range(1,num_i):
        n=j*50
        seq=list(seq)
        seq.insert(n+inter,"\n")
        inter+=1
    new_seq="".join(seq)
    new_fasta=header+"\n"+new_seq
    return new_fasta
    



  

def get_to_file(typ):
    df=pd.read_excel("/hwfssz5/ST_LBI/USER/wangjun/trap/trap_outperformance/dataset/dataset_validation.xlsx",sheet_name=typ)
    df_seq=df["30mer"].values
    df_eff=df["Efficiency"].values
    df_seq1=val_pam(df_seq)
    new_seq=""
    all_list=[]
    m=0
    new_str=""
    for index,i in enumerate(df_seq1):
        num=index+1
        new_seq+=i
        if num%5==0: 
            m+=1
            raw_fasta=">"+str(m)+"\n"+new_seq+"\n"
            new_fasta=get_std_fasta(raw_fasta)
            new_str+=new_fasta
            new_seq=""
    with open("%s.fasta" % typ,"w") as f1:
        f1.write(new_str)
    os.popen("Fasta2Spacer -5 24 -3 6 -i %s.fasta -o %s.spacer.seq" % (typ,typ))
    os.popen("SSC -l 30 -m matrix/human_mouse_CRISPR_KO_30bp.matrix -i %s.spacer.seq -o %s_SSC.out" % (typ,typ))
    return df_seq1
def rsl_to_file(typ):
    print("Doing %s" % typ)
    df_seq1=get_to_file(typ)
    header="30mer\t"+"start\t"+"end\t"+"strand\t"+"name\t"+"score\n"
    with open("%s_SSC.out" % typ,"r") as f2:
        all=f2.read()
        new_all=header+all
    with open("%s_SSC_head.out" % typ,"w") as f3:
        f3.write(new_all)
    rsl_df=pd.read_table("%s_SSC_head.out" % typ,sep="\t",header=[0])
    print(rsl_df.shape)
    seq30=rsl_df["30mer"]
    score=rsl_df["score"]
    score_lst=[]
    new_dict=dict(zip(seq30,score))
    i=0
    #print(new_dict.keys())
    #print(df_seq1)
    for seq in list(df_seq1):
        #print(seq)
        if seq in new_dict.keys():
            it_score=new_dict[seq] 
            score_lst.append(it_score)
        else:
            print(seq)
            i+=1
            score_lst.append("na")
    print("%d not in" % i)
    output=pd.DataFrame({"30mer":df_seq1,"SSC":score_lst})
    output.to_csv("%s.rsl.csv" % typ,sep=",")

#rsl_to_file("Trap-seq")
rsl_to_file("HEL")
rsl_to_file("Doench_V1")
rsl_to_file("Doench_V2")
rsl_to_file("HL60")
rsl_to_file("hela_2")

rsl_to_file("hela_1")
rsl_to_file("hek293t")
rsl_to_file("hct116_1")
